This folder contians the subcharacter data we collected.
radical.txt and comp.txt are the radical list and component list respectively.
char2radical.txt and char2comp.txt are the mapping between Chinese characters and their radicals or their components respectively.
