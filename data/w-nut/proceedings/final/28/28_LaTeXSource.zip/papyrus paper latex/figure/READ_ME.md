rm -rf /Users/nemanja.spasojevic/src-research/research/papyrus_mini_paper/paper/latex/figure/papyrus_performance_per_language_per_stage/; 
cp -r /Users/nemanja.spasojevic/src-research/research/entity_disambiguation/paper/latex/figure/papyrus_performance_per_language_per_stage /Users/nemanja.spasojevic/src-research/research/papyrus_mini_paper/paper/latex/figure/;

