#!/usr/bin/perl
# check the second column of comma-delimited input
# ensures the column is increasing by adding last value at every drop

use strict;

my $basis = "" ; # uvazujene nas vi i
my $laststep = undef;
while (<>) {
  if (/a-z/) {
    print $_;
    next;
  }
  chomp;
  my ($date, $step, $val) = split /,/;
  if (defined $laststep && $laststep > $step) {
    # drop detected, add laststep
    $basis += $laststep;
  }
  $laststep = $step;
  $step += $basis;
  print "$date,$step,$val\n";
}
